import io, os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["BG_DB"] = os.path.join(tempfile.mkdtemp(), "t.db")
import app as A


class AppTests(unittest.TestCase):
    def setUp(self):
        A.new_orch(os.environ["BG_DB"])
        self.c = A.app.test_client()

    def test_intake_and_duplicate_guard(self):
        b = {"case_id": "T1", "text": "Parcel late", "platform": "X", "author_type": "Identified Customer", "current_reach": "Low"}
        self.assertTrue(self.c.post("/api/intake", json=b).json["ok"])
        r = self.c.post("/api/intake", json=b)
        self.assertEqual(r.status_code, 400)
        self.assertIn("already exists", r.json["error"])

    def test_missing_text_rejected_without_record(self):
        r = self.c.post("/api/intake", json={"text": ""})
        self.assertFalse(r.json["ok"])
        self.assertEqual(self.c.get("/api/desk").json["counts"]["all"], 0)

    def test_upload_text_only_and_template_row_skipped(self):
        csv = b"case_id,text\nEXAMPLE,ignore me\n,My order arrived broken\n"
        r = self.c.post("/api/upload", data={"file": (io.BytesIO(csv), "a.csv")}, content_type="multipart/form-data").json
        self.assertEqual((r["processed"], r["skipped"], r["problem_total"]), (1, 1, 0))

    def test_upload_rejects_other_types(self):
        r = self.c.post("/api/upload", data={"file": (io.BytesIO(b"x"), "a.pdf")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_pause_blocks_send_and_keeps_decision_open(self):
        self.c.post("/api/intake", json={"case_id": "T2", "text": "My order arrived today but the serum bottle was leaking, I want a replacement",
                                         "platform": "Instagram", "author_type": "Identified Customer", "current_reach": "Low", "evidence": "supports"})
        d = [i for i in self.c.get("/api/desk?bucket=decide").json["items"] if i["case_id"] == "T2"]
        if d:
            self.c.post("/api/pause", json={"on": True})
            r = self.c.post("/api/cases/T2/decide", json={"action": "approve", "actor": d[0]["decision"]["role"]})
            self.assertFalse(r.json["ok"])
            self.assertIn("paused", r.json["error"])


if __name__ == "__main__":
    unittest.main()
